package no.appsonite.gpsping.utils.bus;

/**
 * Created: Belozerov
 * Company: APPGRANULA LLC
 * Date: 19.02.2016
 */
public class LogoutEvent {
}
