package no.appsonite.gpsping.enums;

/**
 * Created by taras on 11/3/17.
 */

public enum MapStyle {
    TOPO, STANDARD, SATELLITE
}
