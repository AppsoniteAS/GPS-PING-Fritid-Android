package no.appsonite.gpsping.enums;

/**
 * Created by taras on 10/25/17.
 */

public enum DirectionPin {
    NORTH, SOUTH, WEST, EAST, NORTHWEST, NORTHEAST, SOUTHWEST, SOUTHEAST
}
