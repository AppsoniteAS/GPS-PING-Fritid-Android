package no.appsonite.gpsping.utils;

/**
 * Created: Belozerov
 * Company: APPGRANULA LLC
 * Date: 19.02.2016
 */
public class ErrorCode {
    public static final long INVALID_AUTH_COOKIE = 5;
    public static final long INVALID_AUTH_COOKIE_USER = 211;
}
