package no.appsonite.gpsping;

import android.support.v4.content.FileProvider;

/**
 * Created by taras on 11/2/17.
 */

public class WTFileProvider extends FileProvider {
    public static final String AUTHORITY = BuildConfig.FILE_PROVIDER_AUTHORITY;
}
